import { describe, expect, it } from 'vitest'
import * as THREE from 'three'
import { AdaptiveAI } from '../src/game/AdaptiveAI'
import { PlayerPerformanceTracker } from '../src/game/PlayerPerformanceTracker'
import { ProceduralLevelGenerator } from '../src/game/ProceduralLevelGenerator'
import { validateRoute, validateSegment } from '../src/game/ReachabilityValidator'

describe('AI Platform Jumper procedural systems', () => {
  it('reproduces a route from a seed and varies a new seed', () => {
    const generator = new ProceduralLevelGenerator()
    const a = generator.generate(501, 'Normal')
    const b = generator.generate(501, 'Normal')
    const c = generator.generate(502, 'Normal')
    expect(a.sections.map(s => s.signature)).toEqual(b.sections.map(s => s.signature))
    expect(a.sections.map(s => s.signature)).not.toEqual(c.sections.map(s => s.signature))
    expect(validateRoute(a.sections).reachable).toBe(true)
  })

  it('rejects an impossible mandatory jump', () => {
    const from = { id: 0, position: new THREE.Vector3(0, 0, 0), size: new THREE.Vector3(4, .5, 4), kind: 'safe' as const, obstacle: 'none' as const, crystals: [], signature: 'a' }
    const to = { ...from, id: 1, position: new THREE.Vector3(40, 0, -40), kind: 'finish' as const, signature: 'b' }
    expect(validateSegment(from, to).reachable).toBe(false)
  })

  it('lowers difficulty after repeated failures and respects bounds', () => {
    const ai = new AdaptiveAI('Normal')
    expect(ai.observe({ successfulJumps: 1, failedJumps: 4, falls: 2, movingPlatformAttempts: 0, movingPlatformSuccesses: 0, crystals: 0, crystalsAvailable: 4, elapsed: 20, checkpointUses: 1 }, 20)?.to).toBe('Easy')
    expect(ai.observe({ successfulJumps: 1, failedJumps: 8, falls: 5, movingPlatformAttempts: 0, movingPlatformSuccesses: 0, crystals: 0, crystalsAvailable: 4, elapsed: 40, checkpointUses: 2 }, 40)).toBeNull()
  })

  it('raises difficulty only after sustained success and cooldown', () => {
    const ai = new AdaptiveAI('Normal')
    const metrics = { successfulJumps: 8, failedJumps: 0, falls: 0, movingPlatformAttempts: 2, movingPlatformSuccesses: 2, crystals: 3, crystalsAvailable: 5, elapsed: 30, checkpointUses: 0 }
    expect(ai.observe(metrics, 30)?.to).toBe('Hard')
    expect(ai.observe(metrics, 31)).toBeNull()
  })

  it('tracks rolling success, crystal rate, and jump timing from events', () => {
    const tracker = new PlayerPerformanceTracker()
    tracker.start(0, 4)
    tracker.record('jump-success', 1)
    tracker.record('jump-fail', 3)
    tracker.record('crystal', 4)
    const snapshot = tracker.snapshot(8)
    expect(snapshot.successRate).toBe(.5)
    expect(snapshot.crystalRate).toBe(.25)
    expect(snapshot.averageJumpInterval).toBe(2)
  })
})
