import type { PerformanceEvent } from './PlayerPerformanceTracker'

export type Challenge = { title: string; detail: string; tone: 'cyan' | 'purple' | 'amber' }

export class ChallengeEventManager {
  current: Challenge = { title: 'ORIENTATION PULSE', detail: 'Reach the next checkpoint to calibrate the route.', tone: 'cyan' }
  private lastFailure: PerformanceEvent['type'] | null = null

  observe(event: PerformanceEvent['type']): void {
    if (event === 'fall' || event === 'jump-fail') this.lastFailure = event
    if (event === 'moving-fail') this.current = { title: 'SKILL TRIAL // TIMING', detail: 'Board the next moving platform while it is inside the cyan window.', tone: 'purple' }
    else if (event === 'fall') this.current = { title: 'ADAPTIVE ESCAPE', detail: 'A wider recovery route is online. Follow the checkpoint beacon.', tone: 'amber' }
    else if (event === 'checkpoint') this.current = { title: 'CHECKPOINT SYNCED', detail: 'Your respawn vector is locked. The next section is a memory remix.', tone: 'cyan' }
  }

  afterDecision(): void {
    if (this.lastFailure) this.current = { title: 'ADAPTIVE ESCAPE', detail: 'The generator is targeting your most recent failure type.', tone: 'amber' }
    else this.current = { title: 'SKILL TRIAL // PRECISION', detail: 'Collect the optional crystal route without leaving the validated path.', tone: 'purple' }
  }
}
