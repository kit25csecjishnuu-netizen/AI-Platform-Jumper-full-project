import * as THREE from 'three'
import { validateSegment, type ReachabilityConfig } from './ReachabilityValidator'

export type DifficultyName = 'Adaptive' | 'Easy' | 'Normal' | 'Hard'
export type PlatformKind = 'safe' | 'moving' | 'echo' | 'checkpoint' | 'finish'

export type DifficultyProfile = {
  name: DifficultyName
  gapMin: number
  gapMax: number
  widthMin: number
  widthMax: number
  heightStep: number
  movingRate: number
  obstacleRate: number
  crystalRate: number
  checkpointEvery: number
}

export type PlatformSection = {
  id: number
  position: THREE.Vector3
  size: THREE.Vector3
  kind: PlatformKind
  movingTo?: THREE.Vector3
  period?: number
  obstacle: 'none' | 'pillar' | 'beam'
  crystals: THREE.Vector3[]
  branch?: boolean
  signature: string
}

export type GeneratedLevel = {
  seed: number
  sections: PlatformSection[]
  start: THREE.Vector3
  finish: THREE.Vector3
  difficulty: DifficultyProfile
  rejectedSegments: number
  memoryPattern: boolean
}

export const DIFFICULTY_PROFILES: Record<Exclude<DifficultyName, 'Adaptive'>, DifficultyProfile> = {
  Easy: { name: 'Easy', gapMin: 3.6, gapMax: 4.5, widthMin: 3.4, widthMax: 4.5, heightStep: 0.24, movingRate: 0.12, obstacleRate: 0.08, crystalRate: 0.9, checkpointEvery: 4 },
  Normal: { name: 'Normal', gapMin: 4.0, gapMax: 5.4, widthMin: 2.8, widthMax: 3.8, heightStep: 0.34, movingRate: 0.26, obstacleRate: 0.2, crystalRate: 0.82, checkpointEvery: 5 },
  Hard: { name: 'Hard', gapMin: 4.5, gapMax: 6.2, widthMin: 2.4, widthMax: 3.2, heightStep: 0.45, movingRate: 0.42, obstacleRate: 0.35, crystalRate: 0.78, checkpointEvery: 6 },
}

export function seededRandom(seed: number): () => number {
  let value = seed >>> 0
  return () => {
    value = (value + 0x6d2b79f5) >>> 0
    let t = value
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export class ProceduralLevelGenerator {
  constructor(private readonly reachability: ReachabilityConfig = {}) {}

  generate(seed: number, requested: DifficultyName = 'Normal', sections = 26): GeneratedLevel {
    const random = seededRandom(seed)
    const base = requested === 'Adaptive' ? DIFFICULTY_PROFILES.Normal : DIFFICULTY_PROFILES[requested]
    const profile = { ...base, name: requested }
    const start = new THREE.Vector3(0, 0, 5)
    const output: PlatformSection[] = [this.makeSection(0, start, new THREE.Vector3(5.4, 0.6, 5.4), 'safe', random, profile)]
    let previous = output[0]
    let rejectedSegments = 0

    for (let index = 1; index < sections; index += 1) {
      let accepted: PlatformSection | undefined
      for (let attempt = 0; attempt < 8 && !accepted; attempt += 1) {
        const angle = (random() - 0.5) * 0.8
        const distance = profile.gapMin + random() * (profile.gapMax - profile.gapMin)
        const dx = Math.sin(angle) * distance
        const dz = -Math.cos(angle) * distance
        const heightDelta = (random() - 0.35) * profile.heightStep * 3
        const top = previous.position.y + heightDelta
        const width = profile.widthMin + random() * (profile.widthMax - profile.widthMin)
        const kind: PlatformKind = index === sections - 1 ? 'finish' : index % profile.checkpointEvery === 0 ? 'checkpoint' : random() < profile.movingRate ? 'moving' : random() < 0.15 ? 'echo' : 'safe'
        const next = new THREE.Vector3(previous.position.x + dx, top, previous.position.z + dz)
        const size = new THREE.Vector3(width, 0.55, width * (0.86 + random() * 0.24))
        const candidate = this.makeSection(index, next, size, kind, random, profile)
        if (validateSegment(previous, candidate, this.reachability).reachable) accepted = candidate
        else rejectedSegments += 1
      }
      if (!accepted) {
        const fallback = new THREE.Vector3(previous.position.x, previous.position.y + Math.min(profile.heightStep, 0.25), previous.position.z - Math.max(3.4, profile.gapMin))
        accepted = this.makeSection(index, fallback, new THREE.Vector3(Math.max(profile.widthMin, 3.8), 0.55, Math.max(profile.widthMin, 3.8)), index === sections - 1 ? 'finish' : index % profile.checkpointEvery === 0 ? 'checkpoint' : 'safe', random, profile)
      }
      output.push(accepted)
      previous = accepted
    }

    // A memory pattern repeats a familiar zig-zag signature with altered spacing in the middle third.
    const memoryPattern = output.length > 10 && output.slice(6, 10).every((section, i) => Math.abs(section.position.x - output[i + 1].position.x) < 3)
    const finish = output[output.length - 1].position.clone().add(new THREE.Vector3(0, 1.6, 0))
    return { seed, sections: output, start: start.clone().add(new THREE.Vector3(0, 1.05, 0)), finish, difficulty: profile, rejectedSegments, memoryPattern }
  }

  private makeSection(id: number, position: THREE.Vector3, size: THREE.Vector3, kind: PlatformKind, random: () => number, profile: DifficultyProfile): PlatformSection {
    const crystals: THREE.Vector3[] = []
    const crystalCount = random() < profile.crystalRate ? (random() < 0.3 ? 2 : 1) : 0
    for (let i = 0; i < crystalCount; i += 1) {
      const offset = (i - (crystalCount - 1) / 2) * Math.min(0.75, size.x * 0.18)
      crystals.push(new THREE.Vector3(position.x + offset, position.y + size.y / 2 + 0.8, position.z))
    }
    const obstacleRoll = random()
    const obstacle = obstacleRoll < profile.obstacleRate * 0.55 ? 'pillar' : obstacleRoll < profile.obstacleRate ? 'beam' : 'none'
    const movingTo = kind === 'moving' ? position.clone().add(new THREE.Vector3((random() - 0.5) * 2.4, (random() - 0.2) * 0.6, (random() - 0.5) * 1.8)) : undefined
    const signature = `${kind}:${Math.round(position.x * 2)}:${Math.round(position.y * 2)}:${Math.round(size.x * 2)}:${obstacle}`
    return { id, position: position.clone(), size, kind, movingTo, period: kind === 'moving' ? 4.8 + random() * 2.7 : undefined, obstacle, crystals, branch: id > 2 && id % 5 === 2, signature }
  }
}

export function difficultyFromScore(score: number): DifficultyName {
  if (score < 0.25) return 'Easy'
  if (score < 0.6) return 'Normal'
  return 'Hard'
}
