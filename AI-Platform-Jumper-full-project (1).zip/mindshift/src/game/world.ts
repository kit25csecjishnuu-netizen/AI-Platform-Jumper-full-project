import * as THREE from 'three'
import type { Physics } from '../engine/physics'
import { RAPIER } from '../engine/physics'
import { ProceduralLevelGenerator, type DifficultyName, type PlatformSection, seededRandom } from './ProceduralLevelGenerator'

export type Island = { x: number; z: number; top: number; r: number; cores: number; decor?: boolean }
export const ISLANDS: Island[] = [
  { x: 0, z: 0, top: 0, r: 7, cores: 2, decor: true },
  { x: 15, z: 3, top: 1.5, r: 4, cores: 2, decor: true },
  { x: 24, z: -8, top: 3.2, r: 3.5, cores: 2 },
  { x: 14, z: -19, top: 4.8, r: 4.5, cores: 2, decor: true },
  { x: 0, z: -27, top: 6.5, r: 5, cores: 2, decor: true },
]

const STONE = 1.8
const MAX_GAP = 2.3
const MAX_RISE = 1.05

export function rng(seed: number): () => number { return seededRandom(seed) }

/** Legacy pure helper retained for level tests and route diagnostics. */
export function planStones(a: Island, b: Island): { x: number; z: number; top: number }[] {
  const dx = b.x - a.x
  const dz = b.z - a.z
  const d = Math.hypot(dx, dz)
  const gap = d - a.r - b.r
  const dy = b.top - a.top
  let n = 0
  while ((gap - n * STONE) / (n + 1) > MAX_GAP || Math.abs(dy) / (n + 1) > MAX_RISE) n += 1
  const g = (gap - n * STONE) / (n + 1)
  const out: { x: number; z: number; top: number }[] = []
  for (let i = 1; i <= n; i += 1) {
    const along = a.r + g * i + STONE * (i - 0.5)
    out.push({ x: a.x + (dx / d) * along, z: a.z + (dz / d) * along, top: a.top + (dy * i) / (n + 1) })
  }
  return out
}

export type DroneRoute = { center: THREE.Vector3; radius: number; phase: number; dir: 1 | -1 }

export type MovingPlatform = {
  mesh: THREE.Mesh
  body: RAPIER.RigidBody
  from: THREE.Vector3
  to: THREE.Vector3
  period: number
  phase: number
  delta: THREE.Vector3
  half: THREE.Vector3
}

export class World {
  readonly scene = new THREE.Scene()
  readonly sun: THREE.DirectionalLight
  readonly spawn: THREE.Vector3
  readonly finish: THREE.Vector3
  readonly coreSpots: THREE.Vector3[] = []
  readonly checkpointSpots: THREE.Vector3[] = []
  readonly movers: MovingPlatform[] = []
  readonly level: ReturnType<ProceduralLevelGenerator['generate']>
  private readonly echoSections: Array<{ mesh: THREE.Object3D; section: PlatformSection }> = []
  private readonly beacons: THREE.Object3D[] = []
  private time = 0

  constructor(private readonly physics: Physics, shadowMapSize: number, difficulty: DifficultyName = 'Normal', seed = (Date.now() ^ Math.floor(Math.random() * 0x7fffffff)) >>> 0) {
    const generator = new ProceduralLevelGenerator({ jumpSpeed: 10.5, gravity: -30, horizontalSpeed: 10.8 })
    this.level = generator.generate(seed, difficulty, 28)
    this.spawn = this.level.start.clone()
    this.finish = this.level.finish.clone()
    this.scene.background = new THREE.Color('#05091c')
    this.scene.fog = new THREE.Fog('#05091c', 32, 115)
    this.scene.add(this.makeSky())
    this.scene.add(this.makeStars())
    this.scene.add(new THREE.HemisphereLight('#6ee7ff', '#05071a', 1.25))
    this.sun = new THREE.DirectionalLight('#baf6ff', 2.4)
    this.sun.castShadow = true
    this.sun.shadow.mapSize.set(shadowMapSize, shadowMapSize)
    this.sun.shadow.camera.left = -24
    this.sun.shadow.camera.right = 24
    this.sun.shadow.camera.top = 24
    this.sun.shadow.camera.bottom = -24
    this.sun.shadow.camera.near = 1
    this.sun.shadow.camera.far = 100
    this.sun.shadow.bias = -0.0004
    this.sun.shadow.normalBias = 0.03
    this.scene.add(this.sun, this.sun.target)
    this.buildLevel()
  }

  update(dt: number, focus: THREE.Vector3): void {
    this.time += dt
    this.sun.position.set(focus.x + 16, focus.y + 28, focus.z + 12)
    this.sun.target.position.copy(focus)
    for (const { mesh, section } of this.echoSections) {
      const passed = focus.z < section.position.z - 1.3
      mesh.visible = !passed || Math.sin(this.time * 8 + section.id) > -0.75
    }
    for (const beacon of this.beacons) {
      beacon.rotation.y += dt * 0.7
      beacon.scale.setScalar(1 + Math.sin(this.time * 3 + beacon.position.z) * 0.08)
    }
  }

  stepMovers(elapsed: number): void {
    for (const mover of this.movers) {
      const t = ((elapsed + mover.phase) % mover.period) / mover.period
      const tri = t < 0.5 ? t * 2 : 2 - t * 2
      const k = THREE.MathUtils.smootherstep(THREE.MathUtils.clamp((tri - 0.12) / 0.76, 0, 1), 0, 1)
      const target = new THREE.Vector3().lerpVectors(mover.from, mover.to, k)
      const cur = mover.body.translation()
      mover.delta.set(target.x - cur.x, target.y - cur.y, target.z - cur.z)
      mover.body.setNextKinematicTranslation(target)
    }
  }

  private buildLevel(): void {
    for (const section of this.level.sections) {
      const isMoving = section.kind === 'moving'
      const half = new THREE.Vector3(section.size.x / 2, section.size.y / 2, section.size.z / 2)
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(section.size.x, section.size.y, section.size.z), platformMaterial(section.kind))
      mesh.position.set(section.position.x, section.position.y - half.y, section.position.z)
      mesh.castShadow = true
      mesh.receiveShadow = true
      this.scene.add(mesh)
      addPlatformTrim(mesh, section, half)
      if (isMoving && section.movingTo) {
        const from = mesh.position.clone()
        const to = section.movingTo.clone().setY(section.movingTo.y - half.y)
        const body = this.physics.addKinematic(mesh, RAPIER.ColliderDesc.cuboid(half.x, half.y, half.z).setFriction(1))
        this.movers.push({ mesh, body, from, to, period: section.period ?? 6, phase: section.id * 0.83, delta: new THREE.Vector3(), half })
      } else {
        this.physics.addStaticBox(mesh.position, section.size)
      }
      if (section.kind === 'echo') this.echoSections.push({ mesh, section })
      if (section.kind === 'checkpoint') this.addCheckpoint(section)
      if (section.kind === 'finish') this.addFinish(section)
      for (const crystal of section.crystals) this.coreSpots.push(crystal)
      if (section.obstacle !== 'none') this.addObstacle(section, half)
      if (section.branch) this.addRewardBranch(section)
    }
  }

  private addCheckpoint(section: PlatformSection): void {
    const beacon = new THREE.Group()
    beacon.position.set(section.position.x, section.position.y + 0.5, section.position.z)
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.68, 0.045, 8, 30), neon('#64f4ff', 3.5))
    ring.rotation.x = Math.PI / 2
    const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.4, 8), neon('#7c5cff', 3))
    pillar.position.y = 0.7
    beacon.add(ring, pillar)
    this.scene.add(beacon)
    this.beacons.push(beacon)
    this.checkpointSpots.push(section.position.clone().add(new THREE.Vector3(0, 1.05, 0)))
  }

  private addFinish(section: PlatformSection): void {
    const portal = new THREE.Group()
    portal.position.set(section.position.x, section.position.y + 1.75, section.position.z)
    const outer = new THREE.Mesh(new THREE.TorusGeometry(1.15, 0.12, 12, 40), neon('#b475ff', 5))
    const inner = new THREE.Mesh(new THREE.TorusGeometry(0.82, 0.04, 8, 32), neon('#64f4ff', 4))
    portal.add(outer, inner)
    this.scene.add(portal)
    this.beacons.push(portal)
  }

  private addObstacle(section: PlatformSection, half: THREE.Vector3): void {
    const x = section.position.x + half.x * 0.32
    const z = section.position.z
    if (section.obstacle === 'pillar') {
      const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.32, 1.35, 10), neon('#ff4dd8', 1.8))
      mesh.position.set(x, section.position.y + 0.67, z)
      mesh.castShadow = true
      this.scene.add(mesh)
      this.physics.addStaticCylinder(mesh.position, 0.32, 1.35, 0.1)
    } else {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(Math.max(0.8, half.x * 1.3), 0.18, 0.18), neon('#ffbd58', 2.2))
      mesh.position.set(section.position.x, section.position.y + 0.55, z - half.z * 0.2)
      mesh.castShadow = true
      this.scene.add(mesh)
      this.physics.addStaticBox(mesh.position, new THREE.Vector3(Math.max(0.8, half.x * 1.3), 0.18, 0.18), undefined, 0.1)
    }
  }

  private addRewardBranch(section: PlatformSection): void {
    const branch = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.38, 1.8), neon('#7c5cff', 2.4))
    branch.position.set(section.position.x + 2.25, section.position.y - 0.18, section.position.z + 0.3)
    branch.rotation.y = 0.35
    this.scene.add(branch)
    this.physics.addStaticBox(branch.position, new THREE.Vector3(1.8, 0.38, 1.8), branch.quaternion)
    this.coreSpots.push(branch.position.clone().setY(section.position.y + 0.65))
  }

  private makeSky(): THREE.Mesh {
    const mat = new THREE.ShaderMaterial({ side: THREE.BackSide, depthWrite: false, fog: false, uniforms: { top: { value: new THREE.Color('#111b52') }, horizon: { value: new THREE.Color('#05091c') } }, vertexShader: 'varying vec3 vDir; void main(){vDir=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}', fragmentShader: 'uniform vec3 top; uniform vec3 horizon; varying vec3 vDir; void main(){float h=clamp(vDir.y,-1.0,1.0); vec3 c=mix(horizon,top,pow(max(h,0.0),0.6)); gl_FragColor=vec4(c,1.0);}' })
    const sky = new THREE.Mesh(new THREE.SphereGeometry(260, 24, 16), mat)
    sky.renderOrder = -1
    return sky
  }

  private makeStars(): THREE.Points {
    const random = seededRandom(this.level.seed ^ 0x9e3779b9)
    const positions = new Float32Array(420 * 3)
    for (let i = 0; i < 420; i += 1) {
      positions[i * 3] = (random() - 0.5) * 180
      positions[i * 3 + 1] = 14 + random() * 80
      positions[i * 3 + 2] = (random() - 0.5) * 180
    }
    const geometry = new THREE.BufferGeometry()
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    return new THREE.Points(geometry, new THREE.PointsMaterial({ color: '#8ffaff', size: 0.16, transparent: true, opacity: 0.8, sizeAttenuation: true }))
  }
}

function platformMaterial(kind: PlatformSection['kind']): THREE.MeshStandardMaterial {
  const color = kind === 'checkpoint' ? '#19d6c7' : kind === 'finish' ? '#995dff' : kind === 'moving' ? '#37a7ff' : kind === 'echo' ? '#7b5cff' : '#182e61'
  const emissive = kind === 'finish' ? '#7c3cff' : kind === 'echo' ? '#3d2ea8' : '#052b4f'
  return new THREE.MeshStandardMaterial({ color, emissive, emissiveIntensity: kind === 'safe' ? 0.65 : 1.5, metalness: 0.62, roughness: 0.26, transparent: kind === 'echo', opacity: kind === 'echo' ? 0.78 : 1 })
}

function addPlatformTrim(mesh: THREE.Mesh, section: PlatformSection, half: THREE.Vector3): void {
  const trim = new THREE.Mesh(new THREE.BoxGeometry(section.size.x * 0.92, 0.06, 0.08), neon(section.kind === 'finish' ? '#c084fc' : '#27e9ff', 2.5))
  trim.position.set(0, half.y + 0.025, -half.z * 0.86)
  mesh.add(trim)
}

function neon(color: string, intensity: number): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: intensity, metalness: 0.35, roughness: 0.2 })
}
