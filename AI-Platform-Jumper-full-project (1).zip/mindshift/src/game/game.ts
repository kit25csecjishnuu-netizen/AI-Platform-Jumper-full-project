import * as THREE from 'three'
import type { Audio } from '../engine/audio'
import type { Input } from '../engine/input'
import { Physics } from '../engine/physics'
import type { Renderer } from '../engine/renderer'
import type { Quality } from '../engine/save'
import { FollowCamera } from './camera'
import { Collectibles } from './collectibles'
import { AdaptiveAI, type AIDecision } from './AdaptiveAI'
import { ChallengeEventManager } from './ChallengeEventManager'
import { CONFIG } from './config'
import { Effects } from './fx'
import { Player, type PlayerEvent } from './player'
import { PlayerPerformanceTracker } from './PlayerPerformanceTracker'
import { completeAtPortal, collect, createRun, damage, checkpoint, tick, type RunState } from './rules'
import type { DifficultyName } from './ProceduralLevelGenerator'
import { World } from './world'

export type Mode = 'attract' | 'playing' | 'paused' | 'ended'
export type Hint = 'move' | 'look' | 'jump' | 'dash' | 'cores'
export type Compass = { angle: number; distance: number; rise: number }
export type GameAnalytics = { metrics: ReturnType<PlayerPerformanceTracker['snapshot']>; skill: string; difficulty: DifficultyName; decisions: AIDecision[]; challenge: ChallengeEventManager['current'] }

export type GameHooks = {
  popup(text: string, screen: { x: number; y: number }, kind: 'score' | 'hurt'): void
  hurt(): void
  hint(hint: Hint | null): void
  tutorialDone(): void
  end(run: RunState): void
}

export class Game {
  mode: Mode = 'attract'
  run: RunState
  reducedMotion = false
  selectedDifficulty: DifficultyName = 'Adaptive'
  readonly tracker = new PlayerPerformanceTracker()
  readonly ai = new AdaptiveAI('Adaptive')
  readonly challenge = new ChallengeEventManager()
  readonly world: World
  readonly player: Player
  readonly cores: Collectibles
  private readonly physics: Physics
  private readonly cam: FollowCamera
  private readonly fx = new Effects()
  private simTime = 0
  private time = 0
  private tutorial: Hint | null = null
  private tutorialStart = new THREE.Vector3()
  private lastPosition = new THREE.Vector3()
  private jumpInFlight = false

  constructor(private readonly renderer: Renderer, private readonly input: Input, private readonly audio: Audio, private readonly hooks: GameHooks) {
    this.physics = new Physics(CONFIG.player.gravity)
    this.world = new World(this.physics, renderer.shadowMapSize, 'Normal')
    this.player = new Player(this.physics, this.world.spawn, this.world.movers)
    this.cam = new FollowCamera(this.physics, this.player.collider)
    this.cores = new Collectibles(this.world.coreSpots)
    this.world.scene.add(this.player.root, this.player.shadowMesh, this.cores.group, this.fx.mesh)
    this.run = createRun(this.cores.total)
    this.run.generatedSections = this.world.level.sections.length
    this.cam.reset(this.world.spawn, 0.6)
  }

  get camera(): THREE.PerspectiveCamera { return this.cam.camera }

  configure(difficulty: DifficultyName): void {
    this.selectedDifficulty = difficulty
    this.ai.difficulty = difficulty
  }

  start(tutorial = false): void {
    this.cores.reset()
    this.fx.clear()
    this.ai.difficulty = this.selectedDifficulty
    this.ai.history.length = 0
    this.tracker.start(0, this.cores.total)
    this.challenge.current = { title: 'ORIENTATION PULSE', detail: 'Reach the next checkpoint to calibrate the route.', tone: 'cyan' }
    this.player.teleport(this.world.spawn)
    this.player.facing = 0
    this.cam.pitch = 0.42
    this.cam.reset(this.world.spawn, 0)
    this.run = { ...createRun(this.cores.total), generatedSections: this.world.level.sections.length, difficulty: this.ai.difficulty, highestDifficulty: this.ai.difficulty }
    this.simTime = 0
    this.mode = 'playing'
    this.input.endFrame()
    this.input.takeLook()
    this.tutorial = tutorial ? 'move' : null
    this.tutorialStart.copy(this.world.spawn)
    this.lastPosition.copy(this.world.spawn)
    this.hooks.hint(this.tutorial)
  }

  pause(): void { if (this.mode === 'playing') this.mode = 'paused' }
  resume(): void { if (this.mode !== 'paused') return; this.mode = 'playing'; this.input.endFrame(); this.input.takeLook() }
  toTitle(): void { this.mode = 'attract'; this.hooks.hint(null) }

  setQuality(quality: Quality): void {
    this.renderer.applyQuality(quality)
    this.world.scene.traverse(obj => {
      const material = (obj as THREE.Mesh).material
      for (const m of Array.isArray(material) ? material : material ? [material] : []) m.needsUpdate = true
    })
  }

  step(dt: number): void {
    this.simTime += dt
    const jumpPressed = this.input.consume('jump')
    const dashPressed = this.input.consume('dash')
    const playing = this.mode === 'playing'
    this.world.stepMovers(this.simTime)
    const events: PlayerEvent[] = []
    if (playing) {
      this.player.step(dt, { moveX: this.input.move.x, moveY: this.input.move.y, sprint: this.input.held('sprint'), jumpPressed, jumpHeld: this.input.held('jump'), dashPressed }, this.cam.yaw, events)
    }
    this.physics.step(dt)
    if (!playing) return

    const pos = this.player.position
    for (const event of events) this.onPlayerEvent(event, pos)
    const distanceDelta = pos.distanceTo(this.lastPosition)
    this.run = { ...this.run, distance: this.run.distance + Math.min(distanceDelta, 0.5), level: Math.max(1, Math.floor(Math.max(0, this.world.spawn.z - pos.z) / 12) + 1) }
    this.lastPosition.copy(pos)

    for (const at of this.cores.collect(pos, CONFIG.player.radius + 0.72)) {
      const result = collect(this.run)
      this.run = result.state
      this.tracker.record('crystal', this.simTime)
      this.challenge.observe('crystal')
      this.audio.play('pickup')
      this.fx.burst(at, '#64f4ff', 22, 6)
      this.hooks.popup(`+${result.points}`, this.project(at), 'score')
    }

    for (let i = 0; i < this.world.checkpointSpots.length; i += 1) {
      if (i + 1 <= this.run.checkpointIndex) continue
      if (pos.distanceToSquared(this.world.checkpointSpots[i]) < 3.2) {
        this.run = checkpoint(this.run, i + 1)
        this.tracker.record('checkpoint', this.simTime)
        this.challenge.observe('checkpoint')
        this.audio.play('pickup')
        this.hooks.popup('CHECKPOINT SYNCED', this.project(this.world.checkpointSpots[i]), 'score')
      }
    }

    if (pos.distanceTo(this.world.finish) < 2.2 || this.run.collected >= this.run.total) {
      this.run = completeAtPortal(this.run, CONFIG, this.run.collected >= this.run.total ? 'All energy crystals collected. The personal route is complete.' : 'Finish portal reached. Adaptive route completed.')
    }

    if (pos.y < CONFIG.run.killY) {
      this.tracker.record('fall', this.simTime)
      this.tracker.record('jump-fail', this.simTime)
      this.run = { ...damage(this.run, true).state, failedJumps: this.run.failedJumps + 1 }
      this.challenge.observe('fall')
      this.onHurt(pos)
      if (this.run.phase === 'playing') {
        const respawn = this.world.checkpointSpots[Math.max(0, this.run.checkpointIndex - 1)] ?? this.world.spawn
        this.run = { ...this.run, checkpointsUsed: this.run.checkpointsUsed + (this.run.checkpointIndex > 0 ? 1 : 0) }
        this.player.teleport(respawn)
        this.cam.reset(respawn)
      }
    }

    this.run = tick(this.run, dt)
    this.run = { ...this.run, crystalRate: this.tracker.snapshot(this.simTime).crystalRate, difficulty: this.ai.difficulty, highestDifficulty: this.ai.history.reduce((best, item) => rankDifficulty(item.to) > rankDifficulty(best) ? item.to : best, this.ai.difficulty) }
    if (events.some(event => event.type === 'land') || this.run.falls > 0) this.maybeAdapt()
    this.updateTutorial(pos)
    if (this.run.phase !== 'playing') {
      this.mode = 'ended'
      this.hooks.hint(null)
      this.audio.play(this.run.phase === 'won' ? 'win' : 'lose')
      if (this.run.phase === 'won') this.fx.burst(pos.clone().setY(pos.y + 1), '#64f4ff', 60, 10)
      this.hooks.end(this.run)
    }
  }

  render(alpha: number, frameSeconds: number): void {
    this.time += frameSeconds
    this.physics.sync(alpha)
    const target = this.player.root.position
    if (this.mode === 'attract') {
      const t = this.time * 0.08
      this.cam.camera.position.set(Math.sin(t) * 20, 9 + Math.sin(this.time * 0.25) * 1.5, 8 + Math.cos(t) * 20)
      this.cam.camera.lookAt(0, 1, -22)
    } else {
      const look = this.mode === 'playing' ? this.input.takeLook() : { x: 0, y: 0 }
      if (this.mode === 'playing' && this.tutorial === 'look' && Math.abs(look.x) + Math.abs(look.y) > 0.05) this.advanceTutorial('jump')
      this.cam.update(target, look, frameSeconds, false, this.reducedMotion)
    }
    this.player.animate(frameSeconds, this.time, this.run.invulnerable > 0 && this.mode === 'playing', null)
    this.cores.animate(frameSeconds)
    this.fx.update(frameSeconds)
    this.world.update(frameSeconds, target)
    this.renderer.render(this.world.scene, this.cam.camera)
  }

  analytics(): GameAnalytics {
    return { metrics: this.tracker.snapshot(this.simTime), skill: this.ai.skill(this.tracker.metrics(this.simTime)), difficulty: this.ai.difficulty, decisions: this.ai.history, challenge: this.challenge.current }
  }

  compass(): Compass | null {
    const pos = this.player.position
    let best: THREE.Vector3 | undefined
    let bestD = Infinity
    for (const c of this.cores.remaining()) {
      const d = c.distanceToSquared(pos)
      if (d < bestD) { bestD = d; best = c }
    }
    if (!best) return null
    let angle = Math.atan2(-(best.x - pos.x), -(best.z - pos.z)) - this.cam.yaw
    angle = Math.atan2(Math.sin(angle), Math.cos(angle))
    return { angle, distance: Math.sqrt(bestD), rise: best.y - pos.y }
  }

  project(world: THREE.Vector3): { x: number; y: number } {
    const v = world.clone().project(this.cam.camera)
    const canvas = this.renderer.canvas
    return { x: ((v.x + 1) / 2) * canvas.clientWidth, y: ((1 - v.y) / 2) * canvas.clientHeight }
  }

  private maybeAdapt(): void {
    const decision = this.ai.observe(this.tracker.metrics(this.simTime), this.simTime)
    if (!decision) return
    this.challenge.afterDecision()
    this.run = { ...this.run, aiSummary: decision.reason, difficulty: decision.to, highestDifficulty: rankDifficulty(decision.to) > rankDifficulty(this.run.highestDifficulty as DifficultyName) ? decision.to : this.run.highestDifficulty }
    this.hooks.popup(`AI // ${decision.to.toUpperCase()}`, { x: window.innerWidth * 0.5, y: 110 }, 'score')
  }

  private onPlayerEvent(event: PlayerEvent, pos: THREE.Vector3): void {
    const feet = pos.clone().setY(pos.y - CONFIG.player.halfHeight - CONFIG.player.radius)
    if (event.type === 'jump') {
      this.jumpInFlight = true
      this.audio.play('jump')
      this.fx.puff(feet, 0.3)
      if (this.tutorial === 'jump') this.advanceTutorial('dash')
    } else if (event.type === 'land') {
      if (this.jumpInFlight) {
        this.tracker.record('jump-success', this.simTime)
        this.run = { ...this.run, successfulJumps: this.run.successfulJumps + 1 }
        this.jumpInFlight = false
      }
      this.audio.play('land')
      this.fx.puff(feet, event.impact)
    } else if (event.type === 'dash') {
      this.audio.play('dash')
      this.fx.burst(pos, '#b475ff', 10, 3)
      if (this.tutorial === 'dash') this.advanceTutorial('cores')
    }
  }

  private onHurt(pos: THREE.Vector3): void {
    this.audio.play('hurt')
    this.cam.addShake(0.8)
    this.fx.burst(pos, '#ff4dd8', 30, 8)
    this.hooks.hurt()
    this.hooks.popup('-1 CELL', this.project(pos.clone().setY(pos.y + 1)), 'hurt')
  }

  private updateTutorial(pos: THREE.Vector3): void {
    if (this.tutorial === 'move' && pos.distanceTo(this.tutorialStart) > 2.5) this.advanceTutorial(this.input.method === 'touch' ? 'jump' : 'look')
  }

  private advanceTutorial(next: Hint | null): void { this.tutorial = next; this.hooks.hint(next) }
}

function rankDifficulty(name: DifficultyName): number { return name === 'Easy' ? 0 : name === 'Adaptive' ? 1 : name === 'Normal' ? 2 : 3 }
