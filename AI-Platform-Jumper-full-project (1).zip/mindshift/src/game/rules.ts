import { CONFIG } from './config'

export type RunPhase = 'playing' | 'won' | 'lost'
export type LoseReason = 'time' | 'lives'

export type RunState = {
  unranked: boolean
  phase: RunPhase
  loseReason?: LoseReason
  score: number
  lives: number
  timeLeft: number
  elapsed: number
  collected: number
  total: number
  combo: number
  comboTimer: number
  invulnerable: number
  timeBonus: number
  lifeBonus: number
  successfulJumps: number
  failedJumps: number
  falls: number
  distance: number
  level: number
  generatedSections: number
  difficulty: string
  highestDifficulty: string
  checkpointIndex: number
  checkpointsUsed: number
  startedAt: number
  crystalRate: number
  aiSummary: string
}

export function createRun(totalCores: number, rules = CONFIG): RunState {
  return { unranked: false, phase: 'playing', score: 0, lives: rules.run.lives, timeLeft: rules.run.seconds, elapsed: 0, collected: 0, total: totalCores, combo: 0, comboTimer: 0, invulnerable: 0, timeBonus: 0, lifeBonus: 0, successfulJumps: 0, failedJumps: 0, falls: 0, distance: 0, level: 1, generatedSections: 0, difficulty: 'Adaptive', highestDifficulty: 'Adaptive', checkpointIndex: 0, checkpointsUsed: 0, startedAt: Date.now(), crystalRate: 0, aiSummary: 'Rule-based adaptive calibration active.' }
}

export function tick(s: RunState, dt: number): RunState {
  if (s.phase !== 'playing') return s
  const timeLeft = Math.max(0, s.timeLeft - dt)
  const comboTimer = Math.max(0, s.comboTimer - dt)
  const next = { ...s, timeLeft, elapsed: s.elapsed + dt, comboTimer, combo: comboTimer > 0 ? s.combo : 0, invulnerable: Math.max(0, s.invulnerable - dt) }
  return timeLeft <= 0 ? { ...next, phase: 'lost', loseReason: 'time', aiSummary: 'The route timed out before the finish portal.' } : next
}

export function collect(s: RunState, rules = CONFIG): { state: RunState; points: number } {
  if (s.phase !== 'playing') return { state: s, points: 0 }
  const combo = Math.min(rules.score.comboMax, s.comboTimer > 0 ? s.combo + 1 : 1)
  const points = rules.score.core * combo
  const collected = s.collected + 1
  const crystalRate = collected / Math.max(1, s.total)
  if (collected >= s.total) {
    const timeBonus = Math.ceil(s.timeLeft) * rules.score.timeBonus
    const lifeBonus = s.lives * rules.score.lifeBonus
    return { state: { ...s, phase: 'won', score: s.score + points + timeBonus + lifeBonus, combo, comboTimer: rules.score.comboWindow, collected, crystalRate, timeBonus, lifeBonus, aiSummary: 'All collectibles secured. Route complete.' }, points }
  }
  return { state: { ...s, score: s.score + points, combo, comboTimer: rules.score.comboWindow, collected, crystalRate }, points }
}

export function completeAtPortal(s: RunState, rules = CONFIG, summary = 'Finish portal reached. Adaptive route completed.'): RunState {
  if (s.phase !== 'playing') return s
  const timeBonus = Math.ceil(s.timeLeft) * rules.score.timeBonus
  const lifeBonus = s.lives * rules.score.lifeBonus
  return { ...s, phase: 'won', timeBonus, lifeBonus, score: s.score + timeBonus + lifeBonus + rules.score.finishBonus, aiSummary: summary }
}

export function damage(s: RunState, fell = false, rules = CONFIG): { state: RunState; hurt: boolean } {
  if (s.phase !== 'playing') return { state: s, hurt: false }
  if (!fell && s.invulnerable > 0) return { state: s, hurt: false }
  const lives = s.lives - 1
  const next = { ...s, lives, falls: fell ? s.falls + 1 : s.falls, combo: 0, comboTimer: 0, invulnerable: rules.run.invulnerable }
  if (lives <= 0) return { state: { ...next, lives: 0, phase: 'lost', loseReason: 'lives', aiSummary: 'Multiple falls exhausted the recovery cells.' }, hurt: true }
  return { state: next, hurt: true }
}

export function checkpoint(s: RunState, index: number, rules = CONFIG): RunState {
  if (index <= s.checkpointIndex) return s
  return { ...s, checkpointIndex: index, score: s.score + rules.score.checkpointBonus }
}

export function stars(s: RunState, rules = CONFIG): number {
  if (s.phase !== 'won') return 0
  let n = 1
  if (s.timeLeft >= rules.run.seconds / 2) n += 1
  if (s.lives === rules.run.lives) n += 1
  return n
}

export function formatClock(seconds: number): string {
  const whole = Math.max(0, Math.ceil(seconds))
  return `${Math.floor(whole / 60)}:${String(whole % 60).padStart(2, '0')}`
}
