import type { AdaptiveMetrics } from './AdaptiveAI'

export type PerformanceEvent = { type: 'jump-success' | 'jump-fail' | 'fall' | 'crystal' | 'checkpoint' | 'moving-success' | 'moving-fail'; at: number }

export class PlayerPerformanceTracker {
  readonly events: PerformanceEvent[] = []
  private readonly recent = 12
  private availableCrystals = 0
  private startedAt = 0

  start(now = 0, availableCrystals = 0): void {
    this.events.length = 0
    this.startedAt = now
    this.availableCrystals = availableCrystals
  }

  setAvailableCrystals(count: number): void { this.availableCrystals = count }

  record(type: PerformanceEvent['type'], now: number): void {
    this.events.push({ type, at: now })
    if (this.events.length > 250) this.events.shift()
  }

  metrics(now: number): AdaptiveMetrics {
    const count = (type: PerformanceEvent['type']) => this.events.filter(e => e.type === type).length
    return {
      successfulJumps: count('jump-success'),
      failedJumps: count('jump-fail'),
      falls: count('fall'),
      movingPlatformAttempts: count('moving-success') + count('moving-fail'),
      movingPlatformSuccesses: count('moving-success'),
      crystals: count('crystal'),
      crystalsAvailable: this.availableCrystals,
      elapsed: Math.max(0, now - this.startedAt),
      checkpointUses: count('checkpoint'),
    }
  }

  rollingSuccessRate(): number {
    const jumps = this.events.filter(e => e.type === 'jump-success' || e.type === 'jump-fail').slice(-this.recent)
    return jumps.length ? jumps.filter(e => e.type === 'jump-success').length / jumps.length : 0
  }

  averageJumpInterval(): number {
    const jumps = this.events.filter(e => e.type === 'jump-success' || e.type === 'jump-fail')
    if (jumps.length < 2) return 0
    let total = 0
    for (let i = 1; i < jumps.length; i += 1) total += jumps[i].at - jumps[i - 1].at
    return total / (jumps.length - 1)
  }

  snapshot(now: number): AdaptiveMetrics & { successRate: number; crystalRate: number; averageJumpInterval: number } {
    const metrics = this.metrics(now)
    return { ...metrics, successRate: this.rollingSuccessRate(), crystalRate: metrics.crystals / Math.max(1, metrics.crystalsAvailable), averageJumpInterval: this.averageJumpInterval() }
  }
}
