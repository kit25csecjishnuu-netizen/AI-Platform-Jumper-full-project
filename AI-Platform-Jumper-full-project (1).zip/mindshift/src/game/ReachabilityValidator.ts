import type { PlatformSection } from './ProceduralLevelGenerator'

export type ReachabilityConfig = {
  jumpSpeed?: number
  gravity?: number
  horizontalSpeed?: number
  playerRadius?: number
  maxAirTime?: number
}

export type ReachabilityResult = {
  reachable: boolean
  horizontalDistance: number
  verticalDelta: number
  maximumHeight: number
  flightTime: number
  reason: string
}

export function validateSegment(from: PlatformSection, to: PlatformSection, config: ReachabilityConfig = {}): ReachabilityResult {
  const jumpSpeed = config.jumpSpeed ?? 10.5
  const gravity = Math.abs(config.gravity ?? -30)
  const horizontalSpeed = config.horizontalSpeed ?? 10.5
  const radius = config.playerRadius ?? 0.42
  const maxAirTime = config.maxAirTime ?? (jumpSpeed * 2) / gravity
  const dx = to.position.x - from.position.x
  const dz = to.position.z - from.position.z
  const horizontalDistance = Math.hypot(dx, dz)
  const verticalDelta = to.position.y - from.position.y
  const maximumHeight = (jumpSpeed * jumpSpeed) / (2 * gravity)
  const landingTime = Math.max(0.1, Math.min(maxAirTime, (jumpSpeed + Math.sqrt(Math.max(0, jumpSpeed * jumpSpeed - 2 * gravity * verticalDelta))) / gravity))
  const maxHorizontalDistance = horizontalSpeed * maxAirTime + Math.max(from.size.x, to.size.x) * 0.2
  const safeVertical = verticalDelta <= maximumHeight * 0.86 && verticalDelta >= -maximumHeight * 1.4
  const safeLanding = to.size.x > radius * 2.1 && to.size.z > radius * 2.1
  const reachable = horizontalDistance <= maxHorizontalDistance && safeVertical && safeLanding
  let reason = 'Validated ballistic arc and landing footprint.'
  if (!safeVertical) reason = 'Vertical difference exceeds the jump envelope.'
  else if (!safeLanding) reason = 'Landing platform is too narrow for the player collider.'
  else if (horizontalDistance > maxHorizontalDistance) reason = 'Horizontal gap exceeds the controlled air distance.'
  return { reachable, horizontalDistance, verticalDelta, maximumHeight, flightTime: landingTime, reason }
}

export function validateRoute(sections: PlatformSection[], config: ReachabilityConfig = {}): { reachable: boolean; rejected: number; reasons: string[] } {
  const reasons: string[] = []
  let rejected = 0
  for (let i = 1; i < sections.length; i += 1) {
    const result = validateSegment(sections[i - 1], sections[i], config)
    if (!result.reachable) {
      rejected += 1
      reasons.push(`${i}: ${result.reason}`)
    }
  }
  return { reachable: rejected === 0, rejected, reasons }
}
