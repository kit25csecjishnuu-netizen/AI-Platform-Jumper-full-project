import type { DifficultyName, DifficultyProfile } from './ProceduralLevelGenerator'
import { DIFFICULTY_PROFILES } from './ProceduralLevelGenerator'

export type AdaptiveMetrics = {
  successfulJumps: number
  failedJumps: number
  falls: number
  movingPlatformAttempts: number
  movingPlatformSuccesses: number
  crystals: number
  crystalsAvailable: number
  elapsed: number
  checkpointUses: number
}

export type AIDecision = {
  at: number
  from: DifficultyName
  to: DifficultyName
  reason: string
  adjustments: string[]
}

const rank: Record<DifficultyName, number> = { Easy: 0, Adaptive: 1, Normal: 1, Hard: 2 }

export class AdaptiveAI {
  difficulty: DifficultyName
  readonly history: AIDecision[] = []
  private lastAdjustment = -Infinity
  private readonly cooldown = 16

  constructor(initial: DifficultyName = 'Adaptive', private readonly min: DifficultyName = 'Easy', private readonly max: DifficultyName = 'Hard') {
    this.difficulty = initial
  }

  observe(metrics: AdaptiveMetrics, now: number): AIDecision | null {
    const attempts = metrics.successfulJumps + metrics.failedJumps
    if (attempts < 3 || now - this.lastAdjustment < this.cooldown) return null
    const rate = metrics.successfulJumps / Math.max(1, attempts)
    const recentFalls = metrics.falls >= 2 || metrics.failedJumps - metrics.successfulJumps >= 2
    const strongRun = rate >= 0.82 && metrics.successfulJumps >= 6 && metrics.falls === 0
    let target = this.difficulty
    let reason = 'Performance is mixed; keep the current difficulty and vary the pattern.'
    let adjustments = ['Keep platform reachability within the validated jump envelope.']
    if (recentFalls) {
      target = this.step(-1)
      reason = 'Recent jump failures increased. The next section will use wider platforms and shorter gaps.'
      adjustments = ['Increase landing width', 'Shorten the next gaps', 'Slow moving platforms', 'Offer a safer checkpoint']
    } else if (strongRun) {
      target = this.step(1)
      reason = 'Jump success remained high. A more challenging section has been selected.'
      adjustments = ['Add a complex arrangement', 'Introduce a moving platform', 'Open a higher-value risk route']
    }
    if (target === this.difficulty) return null
    const decision = { at: now, from: this.difficulty, to: target, reason, adjustments }
    this.difficulty = target
    this.lastAdjustment = now
    this.history.unshift(decision)
    this.history.splice(8)
    return decision
  }

  profile(): DifficultyProfile {
    const base = this.difficulty === 'Adaptive' ? DIFFICULTY_PROFILES.Normal : DIFFICULTY_PROFILES[this.difficulty]
    if (this.difficulty === 'Easy') return { ...base, gapMax: base.gapMax - 0.4, widthMin: base.widthMin + 0.4, movingRate: 0.08, obstacleRate: 0.05 }
    if (this.difficulty === 'Hard') return { ...base, gapMax: base.gapMax + 0.35, widthMin: Math.max(2.25, base.widthMin - 0.15), movingRate: Math.min(0.5, base.movingRate + 0.06), obstacleRate: Math.min(0.45, base.obstacleRate + 0.04) }
    return { ...base }
  }

  skill(metrics: AdaptiveMetrics): string {
    const rate = metrics.successfulJumps / Math.max(1, metrics.successfulJumps + metrics.failedJumps)
    if (rate >= 0.82) return 'VECTOR // FLOW'
    if (rate >= 0.6) return 'VECTOR // CALIBRATING'
    return 'VECTOR // RECOVERING'
  }

  private step(delta: number): DifficultyName {
    const nextRank = Math.min(rank[this.max], Math.max(rank[this.min], rank[this.difficulty] + delta))
    const names: DifficultyName[] = ['Easy', 'Normal', 'Hard']
    return names[nextRank] ?? 'Normal'
  }
}
