import type { Audio } from '../engine/audio'
import type { I18n } from '../engine/i18n'
import type { Input } from '../engine/input'
import type { SaveData, SaveStore } from '../engine/save'
import { formatClock, type RunState } from '../game/rules'
import type { Compass, GameAnalytics, Hint } from '../game/game'
import type { DifficultyName } from '../game/ProceduralLevelGenerator'
import { loadProfile, recordSession, resetProfile, type PlayerProfile } from '../services/storage'

export type Screen = 'boot' | 'title' | 'setup' | 'hud' | 'pause' | 'analytics' | 'profile' | 'settings' | 'results'
export type UiActions = { play(difficulty?: DifficultyName): void; resume(): void; restart(): void; quit(): void; settings(patch: Partial<SaveData>): void; configure(difficulty: DifficultyName): void }

const esc = (value: string) => value.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c] ?? c))

export class Ui {
  screen: Screen = 'boot'
  private readonly root: HTMLElement
  private readonly stack: Screen[] = []
  private lastRun?: RunState
  private lastAnalytics?: GameAnalytics
  private profile: PlayerProfile = loadProfile()
  private selectedDifficulty: DifficultyName = 'Adaptive'

  constructor(private readonly i18n: I18n, private readonly save: SaveStore, private readonly audio: Audio, private readonly input: Input, private readonly actions: UiActions) {
    this.root = document.getElementById('ui')!
    this.root.innerHTML = this.template()
    document.documentElement.lang = this.i18n.locale
    this.root.addEventListener('click', e => this.onClick(e))
    this.root.addEventListener('input', e => this.onInput(e))
    window.addEventListener('keydown', e => { const target = e.target as HTMLElement | null; if (e.code === 'Escape' && !e.defaultPrevented && !target?.matches('input, textarea')) this.back() })
    this.refreshSettings()
  }

  show(screen: Screen): void { this.stack.length = 0; this.setScreen(screen) }
  push(screen: Screen): void { this.stack.push(this.screen); this.setScreen(screen) }
  back(): void { const previous = this.stack.pop(); if (previous) { this.setScreen(previous); this.input.consume('pause'); window.dispatchEvent(new CustomEvent('ui:escape-back')) } else if (this.screen === 'pause') this.actions.resume() }

  private setScreen(screen: Screen): void {
    this.screen = screen
    for (const el of this.root.querySelectorAll<HTMLElement>('[data-screen]')) {
      const active = el.dataset.screen === screen || (el.dataset.screen === 'hud' && ['pause', 'results'].includes(screen) && this.stack.includes('hud'))
      el.classList.toggle('is-active', active)
      el.setAttribute('aria-hidden', String(!active))
    }
    this.root.dataset.activeScreen = screen
    if (screen === 'analytics') this.renderAnalytics()
    if (screen === 'profile') this.renderProfile()
    if (screen === 'settings') this.refreshSettings()
    requestAnimationFrame(() => { const first = this.root.querySelector<HTMLElement>(`[data-screen="${screen}"] button, [data-screen="${screen}"] input`); if (first && this.input.method !== 'touch') first.focus({ preventScroll: true }) })
  }

  setBootProgress(progress: number): void { const bar = this.root.querySelector<HTMLElement>('.boot-bar i'); if (bar) bar.style.transform = `scaleX(${Math.max(0.04, Math.min(1, progress))})` }

  updateHud(run: RunState, _compass: Compass | null, analytics?: GameAnalytics): void {
    this.lastAnalytics = analytics ?? this.lastAnalytics
    const set = (selector: string, text: string) => { const el = this.root.querySelector<HTMLElement>(selector); if (el) el.textContent = text }
    set('.hud-score', run.score.toLocaleString())
    set('.hud-crystals', `${run.collected} / ${run.total}`)
    set('.hud-level', `LEVEL ${String(run.level).padStart(2, '0')}`)
    set('.hud-distance', `${Math.round(run.distance)} m`)
    set('.hud-time', formatClock(run.timeLeft))
    set('.hud-jumps', `${run.successfulJumps} / ${run.failedJumps}`)
    set('.hud-difficulty', (analytics?.difficulty ?? run.difficulty).toUpperCase())
    set('.hud-skill', analytics?.skill ?? 'VECTOR // CALIBRATING')
    set('.hud-challenge-title', analytics?.challenge.title ?? 'ORIENTATION PULSE')
    set('.hud-challenge-detail', analytics?.challenge.detail ?? 'Reach the next checkpoint to calibrate the route.')
    set('.hud-checkpoint', run.checkpointIndex ? `SYNC ${run.checkpointIndex}` : 'NO CHECKPOINT')
    set('.hud-ai-reason', analytics?.decisions[0]?.reason ?? run.aiSummary)
    const bar = this.root.querySelector<HTMLElement>('.hud-progress i'); if (bar) bar.style.transform = `scaleX(${Math.min(1, run.distance / 105)})`
  }

  popup(text: string, at: { x: number; y: number }, kind: 'score' | 'hurt'): void { const el = document.createElement('div'); el.className = `popup popup-${kind}`; el.textContent = text; el.style.left = `${at.x}px`; el.style.top = `${at.y}px`; this.root.querySelector('.popups')?.append(el); el.addEventListener('animationend', () => el.remove()) }
  hurt(): void { const el = this.root.querySelector('.hurt-vignette'); el?.classList.remove('flash'); void (el as HTMLElement)?.offsetWidth; el?.classList.add('flash') }
  hint(hint: Hint | null): void { const el = this.root.querySelector<HTMLElement>('.tutorial-hint'); if (!el) return; el.classList.toggle('is-active', Boolean(hint)); if (hint) el.textContent = hint === 'move' ? 'WASD / ARROWS  •  MOVE THROUGH THE VECTOR' : hint === 'look' ? 'MOUSE  •  ROTATE YOUR ORBIT CAMERA' : hint === 'jump' ? 'SPACE  •  CLEAR THE NEXT GAP' : hint === 'dash' ? 'SHIFT  •  SPRINT INTO THE NEXT LANDING' : 'CRYSTALS  •  OPTIONAL ROUTES INCREASE YOUR SCORE' }
  frame(_seconds: number): void { /* HUD values are updated by the fixed simulation. */ }

  showResults(run: RunState): void {
    this.lastRun = run
    this.profile = recordSession(this.profile, run)
    const set = (selector: string, text: string) => { const el = this.root.querySelector<HTMLElement>(selector); if (el) el.textContent = text }
    set('.result-kicker', run.phase === 'won' ? 'ROUTE COMPLETE' : 'SIGNAL LOST')
    set('.result-title', run.phase === 'won' ? 'AI PLATFORM JUMPER SYNCHRONIZED' : 'RECALIBRATE THE VECTOR')
    set('.result-score', run.score.toLocaleString())
    set('.result-level', `LEVEL ${run.level}`)
    set('.result-time', formatClock(run.elapsed))
    set('.result-jumps', `${run.successfulJumps} / ${run.successfulJumps + run.failedJumps}`)
    set('.result-crystals', `${run.collected} / ${run.total}`)
    set('.result-falls', String(run.falls))
    set('.result-difficulty', run.highestDifficulty)
    set('.result-summary', run.aiSummary)
    this.root.querySelector('.result-pb')?.classList.toggle('is-active', run.score >= this.profile.highestScore)
    this.setScreen('results')
  }

  private renderAnalytics(): void {
    const run = this.lastRun
    const a = this.lastAnalytics
    if (!a) return
    const m = a.metrics
    const set = (selector: string, text: string) => { const el = this.root.querySelector<HTMLElement>(selector); if (el) el.textContent = text }
    set('.analytics-success', `${Math.round(m.successRate * 100)}%`)
    set('.analytics-falls', String(m.falls))
    set('.analytics-crystals', `${m.crystals} / ${m.crystalsAvailable}`)
    set('.analytics-interval', `${m.averageJumpInterval.toFixed(1)}s`)
    set('.analytics-difficulty', a.difficulty)
    set('.analytics-sections', String(run?.generatedSections ?? 0))
    const history = this.root.querySelector('.ai-history')
    if (history) history.innerHTML = a.decisions.length ? a.decisions.map(d => `<li><span>${esc(d.to.toUpperCase())}</span><p>${esc(d.reason)}</p></li>`).join('') : '<li><span>CALIBRATING</span><p>Complete a few jumps to unlock the first adaptive decision.</p></li>'
    const bars = this.root.querySelector('.performance-bars')
    if (bars) bars.innerHTML = Array.from({ length: 10 }, (_, i) => `<i style="height:${18 + Math.round(Math.abs(Math.sin(i * 1.7 + m.successRate * 4)) * 64)}%"></i>`).join('')
  }

  private renderProfile(): void {
    const set = (selector: string, text: string) => { const el = this.root.querySelector<HTMLElement>(selector); if (el) el.textContent = text }
    set('.profile-name', this.profile.nickname)
    set('.profile-games', String(this.profile.gamesPlayed))
    set('.profile-high', this.profile.highestScore.toLocaleString())
    set('.profile-best', this.profile.bestTime ? formatClock(this.profile.bestTime) : '--:--')
    set('.profile-total-crystals', String(this.profile.totalCrystals))
    const attempts = this.profile.successfulJumps + this.profile.failedJumps
    set('.profile-rate', `${Math.round((this.profile.successfulJumps / Math.max(1, attempts)) * 100)}%`)
    const list = this.root.querySelector('.session-list')
    if (list) list.innerHTML = this.profile.sessions.length ? this.profile.sessions.slice(0, 6).map(s => `<li><b>${s.score.toLocaleString()}</b><span>${esc(s.difficulty)} · ${formatClock(s.time)}</span><em>${Math.round(s.successRate * 100)}% sync</em></li>`).join('') : '<li class="empty">No completed routes yet. Start a run.</li>'
  }

  refreshSettings(): void {
    const d = this.save.data
    const volume = this.root.querySelector<HTMLInputElement>('[name="sfxVolume"]'); if (volume) { volume.value = String(d.sfxVolume); volume.style.setProperty('--fill', `${d.sfxVolume * 100}%`) }
    const sensitivity = this.root.querySelector<HTMLInputElement>('[name="sensitivity"]'); if (sensitivity) sensitivity.value = String(d.sensitivity)
    const quality = this.root.querySelector<HTMLElement>('.quality-choice'); if (quality) quality.textContent = d.quality.toUpperCase()
  }

  private onInput(e: Event): void {
    const target = e.target as HTMLInputElement
    if (target.name === 'nickname') { this.profile.nickname = target.value.slice(0, 18) || 'OPERATOR' }
    if (target.name === 'sfxVolume') this.actions.settings({ sfxVolume: Number(target.value) })
    if (target.name === 'sensitivity') this.actions.settings({ sensitivity: Number(target.value) })
  }

  private onClick(e: MouseEvent): void {
    const target = (e.target as HTMLElement).closest<HTMLElement>('[data-action], [data-difficulty]')
    if (!target) return
    this.audio.unlock()
    if (target.dataset.difficulty) { this.selectedDifficulty = target.dataset.difficulty as DifficultyName; this.actions.configure(this.selectedDifficulty); this.root.querySelectorAll('[data-difficulty]').forEach(el => el.classList.toggle('is-selected', el === target)); return }
    const action = target.dataset.action
    if (action === 'play') { this.setScreen('setup'); return }
    if (action === 'start-game' || action === 'continue') { this.actions.play(this.selectedDifficulty); return }
    if (action === 'resume') { this.actions.resume(); return }
    if (action === 'restart') { this.actions.restart(); return }
    if (action === 'quit' || action === 'title') { this.actions.quit(); this.show('title'); return }
    if (action === 'pause') { window.dispatchEvent(new CustomEvent('game:pause')); return }
    if (action === 'analytics') { this.push('analytics'); return }
    if (action === 'profile') { this.push('profile'); return }
    if (action === 'settings') { this.push('settings'); return }
    if (action === 'back') { this.back(); return }
    if (action === 'reset-profile' && window.confirm('Reset all AI Platform Jumper route history and personal bests?')) { resetProfile(); this.profile = loadProfile(); this.renderProfile() }
    if (action === 'results-stats') { this.push('analytics'); return }
  }

  private template(): string {
    return `<div class="screen screen-boot is-active" data-screen="boot"><div class="boot-mark"><span class="mark-glyph">✦</span><b>AI PLATFORM JUMPER</b></div><div class="boot-bar"><i></i></div><p>INITIALIZING ADAPTIVE VECTOR</p></div>
    <section class="screen screen-title" data-screen="title"><div class="scanlines"></div><div class="hero-orbit orbit-a"></div><div class="hero-orbit orbit-b"></div><header class="topbar"><div class="brand-mini"><span>✦</span> AI PLATFORM JUMPER</div><div class="top-status"><i></i> SYSTEM ONLINE <span>v1.0 / OFFLINE-FIRST</span></div></header><div class="hero-copy"><p class="eyebrow">AI-POWERED PROCEDURAL PLATFORM GENERATION</p><h1>TRAIN THE<br><em>UNKNOWN.</em></h1><p class="hero-sub">A reactive 3D platform-jumper that reads your movement, remixes the route, and turns every failure into a new way forward.</p><div class="menu menu-main"><button class="ms-btn primary" data-action="play"><span>PLAY NOW</span><b>↗</b></button><button class="text-btn" data-action="analytics">VIEW AI ANALYTICS <small>→</small></button><button class="text-btn" data-action="profile">PLAYER PROFILE <small>→</small></button></div></div><div class="hero-stats"><div><b>26+</b><span>GENERATED SECTIONS</span></div><div><b>04</b><span>DIFFICULTY STATES</span></div><div><b>∞</b><span>PERSONALIZED RUNS</span></div></div><div class="landing-info"><div><span class="info-index">01</span><b>HOW IT WORKS</b><p>Move. Miss. Adapt. A transparent rule-based AI smooths the next section around your actual performance.</p></div><div><span class="info-index">02</span><b>WHY IT SHIFTS</b><p>Seeded routes stay fair with ballistic reachability validation while risk paths reward precision.</p></div><div><span class="info-index">03</span><b>WHAT YOU COLLECT</b><p>Crystals, checkpoints, memory patterns, echo platforms, and a better read on your own play.</p></div></div><footer class="landing-footer"><span>WASD / ARROWS TO MOVE</span><span>SPACE TO JUMP</span><span>SHIFT TO SPRINT</span><span class="footer-link" data-action="settings">SETTINGS</span></footer></section>
    <section class="screen screen-setup" data-screen="setup"><div class="panel-shell setup-shell"><div class="panel-top"><div class="brand-mini"><span>✦</span> AI PLATFORM JUMPER</div><button class="icon-btn" data-action="title">×</button></div><div class="eyebrow">MISSION CONFIGURATION / 02</div><h2>Choose your <em>vector.</em></h2><p class="panel-lead">The adaptive core will start here, then reshape future sections from your movement data.</p><div class="difficulty-grid">${(['Adaptive','Easy','Normal','Hard'] as DifficultyName[]).map((d, i) => `<button class="difficulty-card ${i === 0 ? 'is-selected' : ''}" data-difficulty="${d}"><span>0${i + 1}</span><b>${d}</b><small>${d === 'Adaptive' ? 'AI calibrates to you' : d === 'Easy' ? 'Wide landings / low pressure' : d === 'Normal' ? 'Balanced signal / moving routes' : 'Tight gaps / complex patterns'}</small></button>`).join('')}</div><div class="setup-grid"><div><span class="label">EXPLORER</span><div class="choice-chip active">◈ NEON NOMAD <small>READY</small></div></div><div><span class="label">ENVIRONMENT</span><div class="choice-chip active">◌ ECHO RIFT <small>LIVE</small></div></div><div><span class="label">AUDIO</span><div class="choice-chip active">◉ SYNTH SIGNAL <small>ON</small></div></div></div><div class="setup-controls"><span><kbd>WASD</kbd> move <kbd>SPACE</kbd> jump <kbd>SHIFT</kbd> sprint <kbd>ESC</kbd> pause</span><button class="ms-btn primary" data-action="start-game"><span>START NEW RUN</span><b>↗</b></button></div></div></section>
    <section class="screen screen-hud" data-screen="hud"><div class="hud-top"><div class="brand-mini"><span>✦</span> AI PLATFORM JUMPER</div><div class="hud-counters"><div><small>SCORE</small><b class="hud-score">0</b></div><div><small>CRYSTALS</small><b class="hud-crystals">0 / 0</b></div><div><small>ROUTE</small><b class="hud-level">LEVEL 01</b></div><div><small>TIME</small><b class="hud-time">4:00</b></div></div><button class="hud-pause" data-action="pause">Ⅱ</button></div><div class="hud-side left"><div class="hud-card"><small>VECTOR CLASS</small><b class="hud-skill">VECTOR // CALIBRATING</b><i class="signal-bars"><u></u><u></u><u></u><u></u></i></div><div class="hud-card"><small>DIFFICULTY</small><b class="hud-difficulty">ADAPTIVE</b><span class="hud-distance">0 m</span></div><div class="hud-card"><small>JUMPS / FAILURES</small><b class="hud-jumps">0 / 0</b></div></div><div class="hud-side right"><div class="challenge-card"><small>CURRENT CHALLENGE</small><b class="hud-challenge-title">ORIENTATION PULSE</b><p class="hud-challenge-detail">Reach the next checkpoint to calibrate the route.</p><span class="hud-checkpoint">NO CHECKPOINT</span></div><div class="ai-card"><div><small>AI INSIGHT</small><b>ADAPTIVE CORE</b></div><p class="hud-ai-reason">Rule-based adaptive calibration active.</p><button class="mini-link" data-action="analytics">OPEN ANALYTICS →</button></div></div><div class="hud-progress"><span>VECTOR DISTANCE</span><i></i></div><div class="tutorial-hint"></div><div class="popups"></div><div class="hurt-vignette"></div></section>
    <section class="screen screen-modal" data-screen="pause"><div class="modal-card pause-card"><span class="eyebrow">RUN PAUSED / SIGNAL HELD</span><h2>Hold the <em>line.</em></h2><p>Your route and checkpoint are safe.</p><div class="menu"><button class="ms-btn primary" data-action="resume"><span>RESUME RUN</span><b>↗</b></button><button class="ghost-btn" data-action="restart">RESTART RUN</button><button class="ghost-btn" data-action="settings">SETTINGS</button><button class="ghost-btn" data-action="quit">EXIT TO TITLE</button></div></div></section>
    <section class="screen screen-data" data-screen="analytics"><div class="panel-shell data-shell"><div class="panel-top"><div><div class="brand-mini"><span>✦</span> AI PLATFORM JUMPER / AI ANALYTICS</div><span class="eyebrow">LIVE PERFORMANCE TELEMETRY</span></div><button class="icon-btn" data-action="back">×</button></div><div class="data-hero"><div><h2>Your route is <em>listening.</em></h2><p>Every value below is generated from the current run and saved sessions.</p></div><div class="analysis-pill"><span>ACTIVE MODEL</span><b>RULE-BASED / EXPLAINABLE</b></div></div><div class="metric-grid"><div><small>JUMP SUCCESS</small><b class="analytics-success">0%</b></div><div><small>TOTAL FALLS</small><b class="analytics-falls">0</b></div><div><small>CRYSTAL RATE</small><b class="analytics-crystals">0 / 0</b></div><div><small>AVG JUMP INTERVAL</small><b class="analytics-interval">0.0s</b></div><div><small>CURRENT DIFFICULTY</small><b class="analytics-difficulty">ADAPTIVE</b></div><div><small>GENERATED SECTIONS</small><b class="analytics-sections">0</b></div></div><div class="analytics-lower"><div class="chart-card"><div class="chart-head"><span>PERFORMANCE HISTORY</span><small>ROLLING WINDOW</small></div><div class="performance-bars"></div><div class="chart-axis"><span>START</span><span>NOW</span></div></div><div class="decision-card"><div class="chart-head"><span>RECENT AI ADJUSTMENTS</span><small>ACTUAL EVENTS</small></div><ul class="ai-history"></ul></div></div></div></section>
    <section class="screen screen-data" data-screen="profile"><div class="panel-shell data-shell"><div class="panel-top"><div><div class="brand-mini"><span>✦</span> AI PLATFORM JUMPER / PROFILE</div><span class="eyebrow">PERSONAL ROUTE MEMORY</span></div><button class="icon-btn" data-action="back">×</button></div><div class="profile-head"><div class="avatar">✦</div><div><span class="label">OPERATOR ID</span><h2 class="profile-name">OPERATOR</h2><input name="nickname" maxlength="18" placeholder="Set nickname" /></div></div><div class="metric-grid profile-metrics"><div><small>GAMES PLAYED</small><b class="profile-games">0</b></div><div><small>HIGHEST SCORE</small><b class="profile-high">0</b></div><div><small>BEST TIME</small><b class="profile-best">--:--</b></div><div><small>TOTAL CRYSTALS</small><b class="profile-total-crystals">0</b></div><div><small>OVERALL SYNC RATE</small><b class="profile-rate">0%</b></div></div><div class="session-card"><div class="chart-head"><span>RECENT SESSIONS</span><small>SAVED LOCALLY</small></div><ul class="session-list"></ul></div><div class="profile-actions"><button class="ghost-btn" data-action="reset-profile">RESET PROGRESS</button><button class="ms-btn primary" data-action="back"><span>RETURN</span><b>↗</b></button></div></div></section>
    <section class="screen screen-modal" data-screen="settings"><div class="modal-card settings-card"><button class="icon-btn" data-action="back">×</button><span class="eyebrow">SYSTEM SETTINGS</span><h2>Tune the <em>signal.</em></h2><label class="setting-row"><span>SFX VOLUME</span><input name="sfxVolume" type="range" min="0" max="1" step="0.05" /></label><label class="setting-row"><span>CAMERA SENSITIVITY</span><input name="sensitivity" type="range" min="0.2" max="3" step="0.1" /></label><div class="setting-row"><span>QUALITY PRESET</span><b class="quality-choice">HIGH</b></div><button class="ghost-btn" data-action="back">DONE</button></div></section>
    <section class="screen screen-modal" data-screen="results"><div class="modal-card result-card"><span class="eyebrow result-kicker">ROUTE COMPLETE</span><h2 class="result-title">MIND SHIFT SYNCHRONIZED</h2><div class="result-score">0</div><div class="result-pb">NEW PERSONAL BEST</div><div class="result-grid"><div><small>LEVEL</small><b class="result-level">LEVEL 1</b></div><div><small>TIME</small><b class="result-time">0:00</b></div><div><small>JUMPS</small><b class="result-jumps">0 / 0</b></div><div><small>CRYSTALS</small><b class="result-crystals">0 / 0</b></div><div><small>FALLS</small><b class="result-falls">0</b></div><div><small>PEAK DIFFICULTY</small><b class="result-difficulty">ADAPTIVE</b></div></div><p class="result-summary">Rule-based adaptive calibration active.</p><div class="menu menu-row"><button class="ms-btn primary" data-action="restart"><span>PLAY AGAIN</span><b>↗</b></button><button class="ghost-btn" data-action="results-stats">VIEW STATISTICS</button><button class="ghost-btn" data-action="title">TITLE</button></div></div></section><div class="touch"><div class="touch-stick"><i></i></div><button data-touch="jump">JUMP</button><button data-touch="dash">SPRINT</button></div>`
  }
}
