import type { RunState } from '../game/rules'

export type PlayerSession = { id: string; at: number; score: number; level: number; time: number; crystals: number; totalCrystals: number; successRate: number; falls: number; difficulty: string; summary: string }
export type PlayerProfile = { nickname: string; gamesPlayed: number; highestScore: number; bestTime: number; totalCrystals: number; successfulJumps: number; failedJumps: number; sessions: PlayerSession[] }

const KEY = 'ai-platform-jumper.profile.v1'
const initial: PlayerProfile = { nickname: 'OPERATOR', gamesPlayed: 0, highestScore: 0, bestTime: 0, totalCrystals: 0, successfulJumps: 0, failedJumps: 0, sessions: [] }

export function loadProfile(): PlayerProfile {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return structuredClone(initial)
    const parsed = JSON.parse(raw) as Partial<PlayerProfile>
    return { ...initial, ...parsed, sessions: Array.isArray(parsed.sessions) ? parsed.sessions.slice(0, 20) : [] }
  } catch { return structuredClone(initial) }
}

export function saveProfile(profile: PlayerProfile): void {
  try { localStorage.setItem(KEY, JSON.stringify(profile)) } catch { /* gameplay remains in memory */ }
}

export function resetProfile(): void { try { localStorage.removeItem(KEY) } catch { /* ignore storage failures */ } }

export function recordSession(profile: PlayerProfile, run: RunState): PlayerProfile {
  const attempts = run.successfulJumps + run.failedJumps
  const session: PlayerSession = { id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, at: Date.now(), score: run.score, level: run.level, time: run.elapsed, crystals: run.collected, totalCrystals: run.total, successRate: attempts ? run.successfulJumps / attempts : 0, falls: run.falls, difficulty: run.highestDifficulty, summary: run.aiSummary }
  const next: PlayerProfile = {
    ...profile,
    gamesPlayed: profile.gamesPlayed + 1,
    highestScore: Math.max(profile.highestScore, run.score),
    bestTime: profile.bestTime === 0 || (run.phase === 'won' && run.elapsed < profile.bestTime) ? run.elapsed : profile.bestTime,
    totalCrystals: profile.totalCrystals + run.collected,
    successfulJumps: profile.successfulJumps + run.successfulJumps,
    failedJumps: profile.failedJumps + run.failedJumps,
    sessions: [session, ...profile.sessions].slice(0, 20),
  }
  saveProfile(next)
  return next
}
