import type { RunState } from '../game/rules'

const API_BASE = '/api'

export async function health(): Promise<boolean> {
  try { const response = await fetch(`${API_BASE}/health`, { signal: AbortSignal.timeout(900) }); return response.ok && (response.headers.get('content-type') ?? '').includes('application/json') } catch { return false }
}

export async function requestDecision(payload: { successfulJumps: number; failedJumps: number; falls: number; checkpoints: number; completionTime: number; currentDifficulty: string }): Promise<Response | null> {
  try {
    return await fetch(`${API_BASE}/ai/decision`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload), signal: AbortSignal.timeout(1200) })
  } catch { return null }
}

export async function syncSession(playerId: string, run: RunState): Promise<boolean> {
  try {
    const response = await fetch(`${API_BASE}/sessions`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ playerName: playerId, level: run.level, score: run.score, completionTime: run.elapsed, successfulJumps: run.successfulJumps, failedJumps: run.failedJumps, falls: run.falls, collectibles: run.collected, seed: 0, difficulty: run.highestDifficulty, completed: run.phase === 'won' }), signal: AbortSignal.timeout(1500) })
    return response.ok
  } catch { return false }
}
