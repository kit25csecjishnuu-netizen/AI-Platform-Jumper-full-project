# AI Platform Jumper Java backend

This Spring Boot 3 / Java 17 module serves the built browser client from `src/main/resources/static` and exposes the AI Platform Jumper REST API under `/api`.

From the project root, build the frontend first, copy `dist/` into `backend/src/main/resources/static/`, then run:

```bash
mvn spring-boot:run
```

The SQLite database is initialized automatically. See the root README for endpoint examples and the full acceptance workflow.
