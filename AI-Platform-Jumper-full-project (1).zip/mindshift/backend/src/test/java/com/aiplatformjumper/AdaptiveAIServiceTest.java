package com.aiplatformjumper;

import static org.junit.jupiter.api.Assertions.*;
import com.aiplatformjumper.model.GameModels.*;
import com.aiplatformjumper.service.*;
import java.util.List;
import org.junit.jupiter.api.Test;

class AdaptiveAIServiceTest {
  @Test void repeatedFailuresReduceDifficulty() {
    DecisionResponse result = new AdaptiveAIService().decide(new PerformanceRequest(1, 4, 2, 0, 20, "Normal"));
    assertEquals("Easy", result.nextDifficulty());
    assertTrue(result.reason().contains("failures"));
  }
  @Test void sustainedSuccessRaisesDifficulty() {
    DecisionResponse result = new AdaptiveAIService().decide(new PerformanceRequest(8, 0, 0, 1, 35, "Normal"));
    assertEquals("Hard", result.nextDifficulty());
  }
  @Test void impossibleGapIsRejected() {
    var validator = new ReachabilityValidatorService();
    var result = validator.validate(List.of(new Platform(0,0,0,4,4,"safe",false,false), new Platform(40,0,-40,4,4,"finish",false,true)));
    assertFalse(result.reachable());
  }
}
