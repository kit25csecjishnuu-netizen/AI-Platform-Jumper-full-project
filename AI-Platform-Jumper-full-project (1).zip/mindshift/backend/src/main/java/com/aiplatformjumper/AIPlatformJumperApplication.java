package com.aiplatformjumper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AIPlatformJumperApplication {
  public static void main(String[] args) {
    SpringApplication.run(AIPlatformJumperApplication.class, args);
  }
}
