package com.aiplatformjumper.service;

import com.aiplatformjumper.model.GameModels.Platform;
import com.aiplatformjumper.model.GameModels.ValidationResponse;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class ReachabilityValidatorService {
  private static final double JUMP_SPEED = 10.5;
  private static final double GRAVITY = 30.0;
  private static final double HORIZONTAL_SPEED = 10.8;
  private static final double PLAYER_RADIUS = .42;

  public ValidationResponse validate(List<Platform> platforms) {
    List<String> reasons = new ArrayList<>();
    for (int i = 1; i < platforms.size(); i++) {
      Platform from = platforms.get(i - 1), to = platforms.get(i);
      double horizontal = Math.hypot(to.x() - from.x(), to.z() - from.z());
      double vertical = to.y() - from.y();
      double maxHeight = JUMP_SPEED * JUMP_SPEED / (2 * GRAVITY);
      double maxDistance = HORIZONTAL_SPEED * ((2 * JUMP_SPEED) / GRAVITY) + Math.max(from.width(), to.width()) * .2;
      if (horizontal > maxDistance) reasons.add(i + ": horizontal gap exceeds controlled air distance");
      if (vertical > maxHeight * .86 || vertical < -maxHeight * 1.4) reasons.add(i + ": height delta exceeds ballistic envelope");
      if (to.width() <= PLAYER_RADIUS * 2.1 || to.depth() <= PLAYER_RADIUS * 2.1) reasons.add(i + ": landing footprint is too narrow");
    }
    boolean startsSafely = !platforms.isEmpty() && platforms.get(0).width() > 2.0;
    boolean finishesSafely = !platforms.isEmpty() && platforms.get(platforms.size() - 1).finish();
    if (!startsSafely) reasons.add("start: starting platform is missing or too narrow");
    if (!finishesSafely) reasons.add("finish: no finish platform was provided");
    return new ValidationResponse(reasons.isEmpty(), reasons.size(), reasons);
  }
}
