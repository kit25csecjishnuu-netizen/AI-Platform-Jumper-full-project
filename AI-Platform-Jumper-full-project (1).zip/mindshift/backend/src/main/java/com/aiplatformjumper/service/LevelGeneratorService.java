package com.aiplatformjumper.service;

import com.aiplatformjumper.model.GameModels.GenerateLevelRequest;
import com.aiplatformjumper.model.GameModels.LevelResponse;
import com.aiplatformjumper.model.GameModels.Platform;
import com.aiplatformjumper.model.GameModels.ValidationResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.springframework.stereotype.Service;

@Service
public class LevelGeneratorService {
  private final ReachabilityValidatorService validator;
  public LevelGeneratorService(ReachabilityValidatorService validator) { this.validator = validator; }

  public LevelResponse generate(GenerateLevelRequest request) {
    Random random = new Random(request.seed());
    List<Platform> accepted = null;
    ValidationResponse validation = null;
    int rejected = 0;
    for (int attempt = 0; attempt < 8 && accepted == null; attempt++) {
      List<Platform> candidate = candidate(random, request.difficulty(), request.platformCount());
      ValidationResponse result = validator.validate(candidate);
      if (result.reachable()) { accepted = candidate; validation = result; } else rejected += result.rejectedSegments();
    }
    if (accepted == null) {
      accepted = fallback(request.platformCount());
      validation = validator.validate(accepted);
    }
    return new LevelResponse(request.seed(), request.difficulty(), accepted, validation.reachable(), rejected + validation.rejectedSegments(), validation.reachable() ? "Validated ballistic route from start to finish." : "Fallback route returned after bounded retries.");
  }

  private List<Platform> candidate(Random random, String difficulty, int count) {
    double gap = switch (difficulty.toLowerCase()) { case "easy" -> 3.8; case "hard" -> 5.2; default -> 4.5; };
    double width = switch (difficulty.toLowerCase()) { case "easy" -> 4.1; case "hard" -> 2.8; default -> 3.4; };
    List<Platform> platforms = new ArrayList<>();
    double x = 0, y = 0, z = 5;
    for (int i = 0; i < count; i++) {
      boolean finish = i == count - 1;
      boolean checkpoint = i > 0 && i % 5 == 0;
      double platformWidth = finish ? 5 : width + random.nextDouble() * .8;
      platforms.add(new Platform(x, y, z, platformWidth, platformWidth, finish ? "finish" : checkpoint ? "checkpoint" : "safe", checkpoint, finish));
      x += (random.nextDouble() - .5) * 2.2;
      y += (random.nextDouble() - .35) * .6;
      z -= gap + (random.nextDouble() - .5) * 1.2;
    }
    return platforms;
  }

  private List<Platform> fallback(int count) {
    List<Platform> platforms = new ArrayList<>();
    for (int i = 0; i < count; i++) platforms.add(new Platform(0, i * .15, 5 - i * 3.6, 4.2, 4.2, i == count - 1 ? "finish" : "safe", i > 0 && i % 5 == 0, i == count - 1));
    return platforms;
  }
}
