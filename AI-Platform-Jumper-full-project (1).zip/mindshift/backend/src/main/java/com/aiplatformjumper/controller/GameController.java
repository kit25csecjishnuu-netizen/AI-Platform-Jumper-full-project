package com.aiplatformjumper.controller;

import com.aiplatformjumper.model.GameModels.*;
import com.aiplatformjumper.service.*;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api")
public class GameController {
  private final LevelGeneratorService levels;
  private final ReachabilityValidatorService validator;
  private final AdaptiveAIService ai;
  private final SQLiteStore store;
  public GameController(LevelGeneratorService levels, ReachabilityValidatorService validator, AdaptiveAIService ai, SQLiteStore store) { this.levels = levels; this.validator = validator; this.ai = ai; this.store = store; }
  @GetMapping("/health") public Map<String, Object> health() { return Map.of("status", "ok", "service", "ai-platform-jumper", "database", "sqlite"); }
  @PostMapping("/levels/generate") public LevelResponse generate(@Valid @RequestBody GenerateLevelRequest request) { return levels.generate(request); }
  @PostMapping("/levels/validate") public ValidationResponse validate(@Valid @RequestBody ValidateLevelRequest request) { return validator.validate(request.platforms()); }
  @PostMapping("/ai/decision") public DecisionResponse decision(@Valid @RequestBody PerformanceRequest request) { return ai.decide(request); }
  @PostMapping("/sessions") @ResponseStatus(HttpStatus.CREATED) public SessionResponse save(@Valid @RequestBody SessionRequest request) { long id = store.save(request); return new SessionResponse(id, id > 0, "Session persisted in SQLite."); }
  @GetMapping("/players/{playerName}/history") public List<Session> history(@PathVariable String playerName, @RequestParam(defaultValue="20") int limit) { return store.history(playerName, limit); }
  @GetMapping("/players/{playerName}/stats") public PlayerStats stats(@PathVariable String playerName) { return store.stats(playerName); }
  @ExceptionHandler(IllegalStateException.class) @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) public Map<String, String> storageError(IllegalStateException e) { throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e); }
}
