package com.aiplatformjumper.service;

import com.aiplatformjumper.model.GameModels.DecisionResponse;
import com.aiplatformjumper.model.GameModels.PerformanceRequest;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class AdaptiveAIService {
  public DecisionResponse decide(PerformanceRequest request) {
    int attempts = request.successfulJumps() + request.failedJumps();
    double rate = attempts == 0 ? 0 : (double) request.successfulJumps() / attempts;
    String current = request.currentDifficulty() == null || request.currentDifficulty().isBlank() ? "Normal" : request.currentDifficulty();
    String next = current;
    String reason = "Performance is mixed; maintain the current difficulty and vary the pattern.";
    List<String> adjustments = List.of("Keep the route inside the validated jump envelope.");
    if (attempts >= 3 && (request.falls() >= 2 || request.failedJumps() - request.successfulJumps() >= 2)) {
      next = step(current, -1);
      reason = "Recent failures increased. The next generated section will use wider platforms and shorter gaps.";
      adjustments = List.of("Increase landing size", "Reduce gap distance", "Lower obstacle density", "Add a checkpoint");
    } else if (attempts >= 6 && rate >= .82 && request.falls() == 0) {
      next = step(current, 1);
      reason = "Jump success stayed high. A more challenging validated section is selected.";
      adjustments = List.of("Increase gap gradually", "Add moderate height changes", "Open a reward path", "Add a moving hazard");
    }
    return new DecisionResponse(current, next, reason, adjustments, rate);
  }

  private String step(String difficulty, int delta) {
    int rank = switch (difficulty.toLowerCase()) { case "easy" -> 0; case "hard" -> 2; default -> 1; };
    int next = Math.max(0, Math.min(2, rank + delta));
    return next == 0 ? "Easy" : next == 2 ? "Hard" : "Normal";
  }
}
