package com.aiplatformjumper.service;

import com.aiplatformjumper.model.GameModels.PlayerStats;
import com.aiplatformjumper.model.GameModels.Session;
import com.aiplatformjumper.model.GameModels.SessionRequest;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class SQLiteStore {
  private final String url;
  public SQLiteStore(@Value("${app.database.path}") String path) {
    try { Path parent = Path.of(path).toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent); } catch (Exception e) { throw new IllegalStateException("Cannot create SQLite data directory", e); }
    this.url = "jdbc:sqlite:" + path;
    init();
  }
  private Connection connection() throws SQLException { return DriverManager.getConnection(url); }
  private void init() {
    String sql = "CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, player_name TEXT NOT NULL, level INTEGER NOT NULL, score INTEGER NOT NULL, completion_time REAL NOT NULL, successful_jumps INTEGER NOT NULL, failed_jumps INTEGER NOT NULL, falls INTEGER NOT NULL, collectibles INTEGER NOT NULL, seed INTEGER NOT NULL, difficulty TEXT NOT NULL, completed INTEGER NOT NULL, created_at TEXT NOT NULL)";
    try (Connection c = connection(); Statement s = c.createStatement()) { s.executeUpdate(sql); } catch (SQLException e) { throw new IllegalStateException("SQLite initialization failed", e); }
  }
  public long save(SessionRequest r) {
    String sql = "INSERT INTO sessions(player_name,level,score,completion_time,successful_jumps,failed_jumps,falls,collectibles,seed,difficulty,completed,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
    try (Connection c = connection(); PreparedStatement p = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
      p.setString(1, r.playerName()); p.setInt(2, r.level()); p.setInt(3, r.score()); p.setDouble(4, r.completionTime()); p.setInt(5, r.successfulJumps()); p.setInt(6, r.failedJumps()); p.setInt(7, r.falls()); p.setInt(8, r.collectibles()); p.setLong(9, r.seed()); p.setString(10, r.difficulty()); p.setBoolean(11, r.completed()); p.setString(12, Instant.now().toString()); p.executeUpdate();
      try (ResultSet rs = p.getGeneratedKeys()) { return rs.next() ? rs.getLong(1) : -1; }
    } catch (SQLException e) { throw new IllegalStateException("Session save failed", e); }
  }
  public List<Session> history(String player, int limit) {
    String sql = "SELECT * FROM sessions WHERE player_name=? ORDER BY created_at DESC LIMIT ?"; List<Session> out = new ArrayList<>();
    try (Connection c = connection(); PreparedStatement p = c.prepareStatement(sql)) { p.setString(1, player); p.setInt(2, Math.min(100, Math.max(1, limit))); try (ResultSet r = p.executeQuery()) { while (r.next()) out.add(read(r)); } return out; } catch (SQLException e) { throw new IllegalStateException("History read failed", e); }
  }
  public PlayerStats stats(String player) {
    List<Session> sessions = history(player, 100); long completed = sessions.stream().filter(Session::completed).count(); int high = sessions.stream().mapToInt(Session::score).max().orElse(0); double avg = sessions.stream().filter(Session::completed).mapToDouble(Session::completionTime).average().orElse(0); long collectibles = sessions.stream().mapToLong(Session::collectibles).sum(); long falls = sessions.stream().mapToLong(Session::falls).sum(); long successes = sessions.stream().mapToLong(Session::successfulJumps).sum(); long attempts = successes + sessions.stream().mapToLong(Session::failedJumps).sum();
    return new PlayerStats(player, sessions.size(), completed, high, avg, collectibles, falls, attempts == 0 ? 0 : (double) successes / attempts, sessions.stream().limit(10).toList());
  }
  private Session read(ResultSet r) throws SQLException { return new Session(r.getLong("id"), r.getString("player_name"), r.getInt("level"), r.getInt("score"), r.getDouble("completion_time"), r.getInt("successful_jumps"), r.getInt("failed_jumps"), r.getInt("falls"), r.getInt("collectibles"), r.getLong("seed"), r.getString("difficulty"), r.getBoolean("completed"), Instant.parse(r.getString("created_at"))); }
}
