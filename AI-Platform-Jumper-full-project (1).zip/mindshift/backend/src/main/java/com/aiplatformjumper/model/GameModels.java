package com.aiplatformjumper.model;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.util.List;

public final class GameModels {
  private GameModels() {}

  public record Platform(double x, double y, double z, double width, double depth, String kind, boolean checkpoint, boolean finish) {}
  public record GenerateLevelRequest(@Min(0) long seed, @NotBlank String difficulty, @Min(5) @Max(80) int platformCount) {}
  public record LevelResponse(long seed, String difficulty, List<Platform> platforms, boolean reachable, int rejectedSegments, String validationSummary) {}
  public record ValidateLevelRequest(@NotNull List<Platform> platforms) {}
  public record ValidationResponse(boolean reachable, int rejectedSegments, List<String> reasons) {}
  public record PerformanceRequest(@Min(0) int successfulJumps, @Min(0) int failedJumps, @Min(0) int falls, @Min(0) int checkpoints, @Min(0) double completionTime, String currentDifficulty) {}
  public record DecisionResponse(String previousDifficulty, String nextDifficulty, String reason, List<String> adjustments, double successRate) {}
  public record SessionRequest(@NotBlank String playerName, @Min(0) int level, @Min(0) int score, @Min(0) double completionTime, @Min(0) int successfulJumps, @Min(0) int failedJumps, @Min(0) int falls, @Min(0) int collectibles, @Min(0) long seed, @NotBlank String difficulty, @NotNull Boolean completed) {}
  public record SessionResponse(long id, boolean saved, String message) {}
  public record Session(long id, String playerName, int level, int score, double completionTime, int successfulJumps, int failedJumps, int falls, int collectibles, long seed, String difficulty, boolean completed, Instant createdAt) {}
  public record PlayerStats(String playerName, long totalGames, long totalCompleted, int highestScore, double averageCompletionTime, long totalCollectibles, long totalFalls, double successRate, List<Session> recentSessions) {}
}
