# AI Platform Jumper

AI Platform Jumper is a complete browser-based 3D platform-jumping game that demonstrates procedural level generation, physics-based reachability validation, and transparent adaptive difficulty. It is not a static dashboard: the player moves, jumps, sprints, lands, falls, respawns at checkpoints, collects crystals, avoids hazards, and reaches a finish portal.

The visible game is intentionally branded **AI Platform Jumper**. The backend uses **Java 17+ with Spring Boot and SQLite**. The browser client uses HTML5, CSS3, JavaScript/TypeScript ES modules, Three.js, Rapier physics, responsive HTML UI, and the generated animated explorer asset.

## Features

- Seeded procedural floating-platform routes with reproducible layouts and different levels for new seeds.
- Dedicated ballistic reachability validation with bounded regeneration and a safe fallback route.
- Rule-based adaptive AI that records successful landings, failed jumps, falls, checkpoints, collectible rate, jump timing, and completion time.
- Difficulty changes are gradual and bounded. Repeated failures widen platforms, shorten gaps, reduce hazards, and add recovery checkpoints; sustained success increases challenge and opens reward routes.
- Third-person camera, gravity, grounded detection, moving and echo platforms, hazards, crystals, checkpoints, finish portal, particles, shadows, lighting, and an animated 3D explorer.
- Keyboard controls: W/A/S/D or arrow keys to move, Space to jump, Shift to sprint, R to restart, Escape to pause/resume. Touch controls are available on narrow screens.
- Landing page, setup screen, HUD, AI information panel, analytics dashboard, player profile/history, pause/settings, and results screen.
- Java REST endpoints for health, authoritative level generation, route validation, AI decisions, SQLite session persistence, player history, and player statistics.
- Frontend calls the Java API for health and session persistence. If the browser preview is running without Spring Boot, the UI clearly remains playable in its local fallback mode and does not invent server statistics.

## Published demo

Play the deployed game at: https://mindshift-bbjuwo2t.manus.game

## Frontend development

```bash
pnpm install
PORT=3000 HOST=0.0.0.0 pnpm dev       # http://localhost:3000
pnpm typecheck
pnpm test
pnpm build
pnpm smoke     # run after build; starts a local preview and checks a route
```

The generated explorer is in `public/assets/ai-platform-jumper-explorer.glb` and is loaded by the Three.js player controller. The source deliverables are also preserved under `assets/models/`.

## Java + SQLite single-application workflow

Install Java 17 or later and Maven 3.9+.

1. Build the browser client:

   ```bash
   pnpm install
   pnpm build
   ```

2. Copy the built browser files into Spring Boot's static resources:

   ```bash
   rm -rf backend/src/main/resources/static
   mkdir -p backend/src/main/resources/static
   cp -r dist/. backend/src/main/resources/static/
   ```

3. Start the Java application:

   ```bash
   cd backend
   mvn spring-boot:run
   ```

4. Open `http://localhost:8080`. Spring Boot serves the game and the REST API from one application. The SQLite file is created at `backend/data/ai-platform-jumper.db` by default. Override it with `APP_DATABASE_PATH=/absolute/path/game.db`.

For a packaged run:

```bash
cd backend
mvn clean package
java -jar target/ai-platform-jumper-backend-1.0.0.jar
```

## Production container

The root `Dockerfile` builds the Vite client, packages it into the Spring Boot application, and starts the single-origin game/API server on the platform-provided `PORT` (8080 locally). Build and run it with:

```bash
docker build -t ai-platform-jumper .
docker run --rm -p 8080:8080 -v "$PWD/backend/data:/app/data" ai-platform-jumper
```

Published routing sends `/api/*` to the Java server and serves hashed frontend assets plus SPA routes from the static build.

## REST API

All request bodies are JSON.

- `GET /api/health` — returns service and SQLite status.
- `POST /api/levels/generate`

  ```json
  {"seed":501,"difficulty":"Normal","platformCount":28}
  ```

- `POST /api/levels/validate`

  ```json
  {"platforms":[{"x":0,"y":0,"z":5,"width":5,"depth":5,"kind":"safe","checkpoint":false,"finish":false}]}
  ```

- `POST /api/ai/decision`

  ```json
  {"successfulJumps":8,"failedJumps":0,"falls":0,"checkpoints":1,"completionTime":42,"currentDifficulty":"Normal"}
  ```

- `POST /api/sessions` — stores a completed or abandoned session in SQLite. Duplicate completion protection is represented by the session id and client-side one-shot submission flow.
- `GET /api/players/{playerName}/history?limit=20` — recent saved sessions.
- `GET /api/players/{playerName}/stats` — totals, best score, average completion time, collectibles, falls, and overall success rate.

The backend returns validation errors as HTTP 400 responses and storage failures as HTTP 500 responses with a meaningful message. SQL writes use prepared statements and the schema is initialized transaction-safely on startup.

## Project layout

```text
src/                         Three.js client and game modules
  engine/                    fixed loop, input, physics, renderer, audio, save
  game/                     player, world, generator, validator, adaptive AI, rules
  services/                 API client and local profile fallback
  ui/                       screens, HUD, analytics, profile and touch controls
backend/                     Java 17 Spring Boot application
  src/main/java/...          controllers, records, generator, AI, validator, SQLite store
  src/test/java/...          adaptive and reachability tests
  pom.xml                   Maven build
public/                      fonts, route manifest, generated explorer GLB
tests/                       TypeScript and browser smoke/unit tests
```

## Automated and manual verification

Frontend tests cover pure scoring rules, deterministic seed behavior, impossible-route rejection, adaptive increases/decreases and bounds, rolling performance metrics, input/loop contracts, save handling, and responsive UI smoke checks. Backend tests cover repeated-failure easing, sustained-success escalation, and impossible-gap rejection.

Manual acceptance:

1. Start with `mvn spring-boot:run` and open `http://localhost:8080`.
2. Choose Adaptive, Easy, Normal, or Hard and start a new route.
3. Use WASD/arrow keys, Space, and Shift to reach platforms, collect crystals, and touch a checkpoint.
4. Intentionally fall twice and inspect the AI insight; then make several successful jumps and inspect the next decision.
5. Finish through the portal or collect every crystal and confirm the results screen.
6. Query `/api/players/OPERATOR/stats` and open Player Profile to confirm real saved sessions are present in SQLite.
7. Repeat with a new browser session and confirm a new generated seed/layout is used by the Three.js route; call `/api/levels/generate` with an explicit seed to reproduce a route.

No trained machine-learning model is claimed. The adaptive system is an explainable, real rule-based algorithm with documented metrics and bounded decisions.
